
(function(){
var D=window.BC_DATA, KEY="baichuan_smithy_v052", LEGACY_KEY="baichuan_smithy_v051", LEGACY_KEY2="baichuan_smithy_v040";
function base(){return{
 gold:880,gems:12,day:1,tab:"shop",forgeLv:1,shelfLv:1,
 mats:{wood:5,ore:2,hide:2,crystal:0,ember:0},
 heroes:[
  {id:"brann",name:"布兰",job:"战士",level:1,base:9,body:window.BC_CHAR.brann,equip:{weapon:null,armor:null,accessory:null}},
  {id:"mira",name:"米拉",job:"斥候",level:1,base:8,body:window.BC_CHAR.mira,equip:{weapon:"woodSword",armor:null,accessory:null}}
 ],
 inventory:[],shelf:[null,null,null],
 flags:{forest:false,forge2:false,iron:false,mine:false,sold:false,boss:false}
}}
function load(){try{var raw=localStorage.getItem(KEY)||localStorage.getItem(LEGACY_KEY)||localStorage.getItem(LEGACY_KEY2),s=raw?JSON.parse(raw):null;if(s&&s.heroes){s.heroes[0].body=window.BC_CHAR.brann;s.heroes[1].body=window.BC_CHAR.mira;return s}}catch(e){}return base()}
var S=load(), app=document.getElementById("app");
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}}
function q(s){return document.querySelector(s)}
function eq(id){return id?D.equipment[id]:null}
function hero(i){return S.heroes[i]}
function pwr(h){var n=h.base,a=[h.equip.weapon,h.equip.armor,h.equip.accessory];for(var i=0;i<a.length;i++)if(a[i])n+=eq(a[i]).power;return n}
function layers(h,slot,id){var e={weapon:h.equip.weapon,armor:h.equip.armor,accessory:h.equip.accessory};if(slot)e[slot]=id;var x='<div class=paper><img src="'+h.body+'">';if(e.armor&&eq(e.armor).overlay)x+='<img src="'+eq(e.armor).overlay+'">';if(e.weapon&&eq(e.weapon).overlay)x+='<img src="'+eq(e.weapon).overlay+'">';if(e.accessory&&eq(e.accessory).overlay)x+='<img src="'+eq(e.accessory).overlay+'">';return x+'</div>'}
function goal(){var f=S.flags;if(!f.forest)return["新手目标","前往翠绿森林探索一次，带回木材和兽皮"];if(!f.forge2)return["成长目标","升级锻造台到 Lv.2"];if(!f.iron)return["装备目标","锻造精铁长剑并给员工穿戴"];if(!f.mine)return["冒险目标","提升战力并探索黑石矿坑"];if(!f.sold)return["经营目标","把一件装备上架并完成一次出售"];if(!f.boss)return["最终目标","打造更强装备，挑战余烬洞窟"];return["Demo完成","你已经跑通基础经营循环"]}
function top(){return '<div class=top><div class=logo><b>百川铁匠铺</b><small>H5 Modular v0.5.2.1</small></div><div class=res><span>金币</span><strong><img src="'+window.BC_COIN+'">'+S.gold+'</strong></div><div class=res><span>魔晶</span><strong><img src="'+window.BC_GEM+'">'+S.gems+'</strong></div></div>'}
function nav(){var a=[["shop",window.BC_UI.shop,"店铺"],["heroes",window.BC_UI.hero,"员工"],["bag",window.BC_UI.bag,"背包"],["adventure",window.BC_UI.adventure,"冒险"],["forge",window.BC_UI.forge,"锻造"]],x='<div class=nav>';for(var i=0;i<a.length;i++)x+='<button class="'+(S.tab===a[i][0]?'on':'')+'" onclick="go(\''+a[i][0]+'\')"><b><img src="'+a[i][1]+'"></b><span>'+a[i][2]+'</span></button>';return x+'</div>'}
function render(){app.innerHTML=top()+'<div class=main>'+view()+'</div>'+nav()}
window.go=function(t){S.tab=t;save();render()}
function view(){if(S.tab==="shop")return shop();if(S.tab==="heroes")return heroes();if(S.tab==="bag")return bag();if(S.tab==="adventure")return adventure();return forge()}
function goalHtml(){var g=goal();return '<div class=goal><small>'+g[0]+'</small><b>'+g[1]+'</b></div>'}
function shop(){var h0=hero(0),h1=hero(1),cnt=0;for(var i=0;i<S.shelf.length;i++)if(S.shelf[i])cnt++;
return '<div class=scroll style="padding:0"><div class=scene><img class=sceneBg src="'+window.BC_HOME.background+'"><div class=sceneShade></div><div class="lightWash cool"></div><div class="lightWash warm"></div>'+
'<div class="homeHero a"><span class=groundShadow></span><img src="'+window.BC_HOME.mira+'"></div><div class="homeName a"><b>米拉</b><small>斥候</small></div>'+
'<div class="homeHero b"><span class=groundShadow></span><img src="'+window.BC_HOME.brann+'"></div><div class="homeName b"><b>布兰</b><small>战士</small></div>'+
'<div class=sceneDock><div class=shopTitle><b>店铺操作</b><span>炉火正旺 · 今日营业中</span></div><div class=actions>'+
'<button class=actionForge onclick="go(&quot;forge&quot;)"><i><img src="'+window.BC_UI.forge+'"></i><b>锻造</b></button>'+
'<button class=actionShelf onclick="shelf()"><i><img src="'+window.BC_UI.shelf+'"></i><b>上架</b></button>'+
'<button class=actionAdventure onclick="go(&quot;adventure&quot;)"><i><img src="'+window.BC_UI.actionAdventure+'"></i><b>冒险</b></button>'+
'<button class=actionChallenge onclick="challenge()"><i><img src="'+window.BC_UI.challenge+'"></i><b>挑战</b></button>'+
'</div></div></div>'+
'<div style="padding:8px">'+goalHtml()+'<div class=panel><div class=pTitle>今日经营</div><div class=pBody><div class=summary><div class=stat><small>店铺</small><b>Lv.'+(S.shelfLv+1)+'</b></div><div class=stat><small>货架</small><b>'+cnt+'/3</b></div><div class=stat><small>总战力</small><b>'+(pwr(h0)+pwr(h1))+'</b></div><div class=stat><small>日期</small><b>Day '+S.day+'</b></div></div></div></div><button class=big onclick="upgradeForge()">升级锻造台 · '+(180*S.forgeLv)+'G</button></div></div>'}
function heroes(){var x='<div class=scroll>'+goalHtml();for(var i=0;i<S.heroes.length;i++){var h=hero(i);x+='<div class=panel><div class=pTitle>'+h.name+' · '+h.job+'</div><div class=pBody><div class=heroCard><div class=stage>'+layers(h)+'</div><div class=hstats><h2>Lv.'+h.level+' '+h.name+'</h2><div class=line><span>基础战力</span><b>'+h.base+'</b></div><div class=line><span>当前战力</span><b>'+pwr(h)+'</b></div><div class=line><span>武器</span><b>'+ename(h.equip.weapon)+'</b></div><div class=line><span>防具</span><b>'+ename(h.equip.armor)+'</b></div><div class=line><span>饰品</span><b>'+ename(h.equip.accessory)+'</b></div><button class=btn style="width:100%;margin-top:8px" onclick="pickEquip('+i+')">更换装备</button></div></div><div class=slots>'+slot("武器",h.equip.weapon)+slot("防具",h.equip.armor)+slot("饰品",h.equip.accessory)+'</div></div></div>'}return x+'</div>'}
function ename(id){return id?eq(id).name:"未装备"}
function slot(n,id){if(!id)return '<div class=slot>＋<b>'+n+'</b></div>';var r=eq(id);return '<div class=slot><img src="'+r.icon+'"><b>'+r.name+'</b></div>'}
window.pickEquip=function(i){if(!S.inventory.length)return toast("背包里还没有装备");var x="";for(var k=0;k<S.inventory.length;k++){var it=S.inventory[k],r=eq(it.id),h=hero(i),old=eq(h.equip[r.slot]),cur=pwr(h),next=cur-(old?old.power:0)+r.power;x+='<div class=rowItem><div class=ibox><img src="'+r.icon+'"></div><div class=info><b>'+it.q+'·'+r.name+'</b><small>'+r.type+' · 穿戴后战力 '+next+'</small></div><button class=btn onclick="compare('+i+','+k+')">对比</button></div>'}modal("选择装备",x,"")}
window.compare=function(hi,ii){var h=hero(hi),it=S.inventory[ii],r=eq(it.id),old=eq(h.equip[r.slot]),cur=pwr(h),next=cur-(old?old.power:0)+r.power,d=next-cur;modal("装备对比",'<div class=heroCard><div class=stage>'+layers(h,r.slot,it.id)+'</div><div class=hstats><h2>'+h.name+'</h2><div class=line><span>当前</span><b>'+cur+'</b></div><div class=line><span>穿戴后</span><b>'+next+'</b></div><div class=line><span>变化</span><b>'+(d>=0?"+":"")+d+'</b></div><div class=line><span>旧装备</span><b>'+(old?old.name:"未装备")+'</b></div><div class=line><span>新装备</span><b>'+r.name+'</b></div></div></div>','<button class=big onclick="wear('+hi+','+ii+')">确认穿戴</button>')}
window.wear=function(hi,ii){var h=hero(hi),it=S.inventory[ii],r=eq(it.id),old=h.equip[r.slot];h.equip[r.slot]=it.id;S.inventory.splice(ii,1);if(old)S.inventory.push({id:old,q:"普通"});if(it.id==="ironSword")S.flags.iron=true;save();closeM();render();toast("已穿戴 "+r.name)}
function bag(){var x='<div class=scroll>'+goalHtml()+'<div class=panel><div class=pTitle>材料</div><div class=pBody><div class=grid>';for(var k in S.mats)x+='<div class=cell><img src="'+D.materials[k].icon+'"><span>'+D.materials[k].name+'</span><b class=qty>'+S.mats[k]+'</b></div>';x+='</div></div></div><div class=panel><div class=pTitle>装备</div><div class=pBody><div class=grid>';for(var i=0;i<S.inventory.length;i++){var it=S.inventory[i],r=eq(it.id);x+='<div class=cell><img src="'+r.icon+'"><span>'+it.q+'·'+r.name+'</span></div>'}if(!S.inventory.length)x+='<div style="grid-column:1/-1;color:#a99073;font-size:9px;padding:12px">暂无装备，先去锻造。</div>';return x+'</div></div></div></div>'}
function canCraft(id){var r=eq(id);if(S.forgeLv<r.forge||S.gold<r.cost)return false;for(var k in r.need)if((S.mats[k]||0)<r.need[k])return false;return true}
function forge(){var x='<div class=scroll>'+goalHtml()+'<div class=panel><div class=pTitle>锻造台 · Lv.'+S.forgeLv+'</div>';for(var id in D.equipment){var r=eq(id),n="";for(var k in r.need)n+='<span class="need '+((S.mats[k]||0)<r.need[k]?'bad':'')+'">'+D.materials[k].name+' '+(S.mats[k]||0)+'/'+r.need[k]+'</span>';x+='<div class=rowItem><div class=ibox><img src="'+r.icon+'"></div><div class=info><b>'+r.name+'</b><small>'+r.type+' · 战力 +'+r.power+' · '+r.cost+'G · 锻造台Lv.'+r.forge+'</small><div>'+n+'</div></div><button class=btn '+(canCraft(id)?'':'disabled')+' onclick="craft(\''+id+'\')">锻造</button></div>'}return x+'</div></div>'}
window.craft=function(id){if(!canCraft(id))return toast("材料、金币或等级不足");var r=eq(id);for(var k in r.need)S.mats[k]-=r.need[k];S.gold-=r.cost;var ql=Math.random()>.78?"精良":"普通";S.inventory.push({id:id,q:ql});save();render();toast("锻造完成："+ql+"·"+r.name)}
function adventure(){var x='<div class=scroll>'+goalHtml();for(var id in D.regions){var r=D.regions[id],drops=[];for(var i=0;i<r.drops.length;i++)drops.push(D.materials[r.drops[i]].name);x+='<div class=map><img src="'+r.image+'"><div class=mapFoot><div><b>'+r.name+'</b><small>推荐战力 '+r.need+'<br>掉落：'+drops.join(" · ")+'</small></div><button class="btn '+(id==="cave"?"red":"secondary")+'" onclick="explore(\''+id+'\')">'+(id==="cave"?"挑战":"探索")+'</button></div></div>'}return x+'</div>'}
window.explore=function(id){var r=D.regions[id],chance=Math.max(.38,Math.min(.96,.65+(pwr(hero(0))-r.need)*.025)),ok=Math.random()<chance,g=[];S.day++;if(ok){for(var i=0;i<r.drops.length;i++){var k=r.drops[i],n=1+Math.floor(Math.random()*3);S.mats[k]=(S.mats[k]||0)+n;g.push(D.materials[k].name+"+"+n)}S.gold+=70+r.need*3;if(id==="forest")S.flags.forest=true;if(id==="mine")S.flags.mine=true;if(id==="cave")S.flags.boss=true}else S.gold=Math.max(0,S.gold-30);save();render();modal(ok?"探索成功":"探索失败",'<div style="text-align:center;padding:10px"><h2 style="color:#f0c86a">'+r.name+'</h2><div style="font-size:9px;color:#cdb795;line-height:1.8">'+(ok?("获得："+g.join(" · ")+"<br>金币增加"):"队伍撤退，损失30G")+'<br>本次成功率 '+Math.round(chance*100)+'%</div></div>',S.flags.boss?'<button class=big onclick="closeM();complete()">查看Demo结算</button>':'')}
window.upgradeForge=function(){var c=180*S.forgeLv;if(S.gold<c)return toast("金币不足");S.gold-=c;S.forgeLv++;S.flags.forge2=true;save();render();toast("锻造台升级到 Lv."+S.forgeLv)}
window.shelf=function(){var x="";for(var i=0;i<S.shelf.length;i++){var id=S.shelf[i];if(!id)x+='<div class=rowItem><div class=ibox>＋</div><div class=info><b>空货架</b><small>自动取背包第一件装备上架</small></div><button class=btn onclick="put('+i+')">上架</button></div>';else{var r=eq(id);x+='<div class=rowItem><div class=ibox><img src="'+r.icon+'"></div><div class=info><b>'+r.name+'</b><small>顾客售价 '+Math.round(r.value*1.2)+'G</small></div><button class="btn secondary" onclick="sell('+i+')">出售</button></div>'}}modal("货架 / 营业",x,"")}
window.put=function(i){if(!S.inventory.length)return toast("背包没有装备");S.shelf[i]=S.inventory.shift().id;save();closeM();shelf()}
window.sell=function(i){var id=S.shelf[i];if(!id)return;var r=eq(id);S.gold+=Math.round(r.value*1.2);S.shelf[i]=null;S.flags.sold=true;save();closeM();render();toast("成交："+r.name)}
window.challenge=function(){modal("挑战","<div style='text-align:center;padding:18px;color:#bba487'>正式版这里会放 Boss委托、限时悬赏和特殊素材挑战。</div>","")}
window.complete=function(){modal("Demo完成","<div style='text-align:center;padding:14px'><h2 style='color:#f0c86a'>铁匠铺已经运转起来</h2><div style='color:#bba487;font-size:9px;line-height:1.8'>你已经体验：冒险采集 → 锻造 → 装备对比 → 换装 → 上架销售 → 高级区域挑战。</div></div>","")}
function modal(t,b,f){closeM();var d=document.createElement("div");d.className="modal";d.innerHTML='<div class=modalBox><div class=mHead><b>'+t+'</b><button class=x onclick="closeM()">×</button></div><div class=mBody>'+b+'</div>'+(f?'<div class=mFoot>'+f+'</div>':'')+'</div>';q(".main").appendChild(d)}
window.closeM=function(){var m=q(".modal");if(m)m.remove()}
function toast(t){var d=document.createElement("div");d.className="toast";d.textContent=t;q(".main").appendChild(d);setTimeout(function(){if(d.parentNode)d.remove()},1400)}
render();
})();
