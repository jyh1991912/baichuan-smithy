
(function(){
'use strict';

var SAVE_KEY='baichuan_smithy_save_v2';
var OLD_KEYS=['baichuan_smithy_save_v1','baichuan_smithy_v052','baichuan_smithy_v051','baichuan_smithy_v040'];
var app=document.getElementById('app');

var QUALITY={
 common:{name:'普通',rank:0,power:1.00,value:1.00,cls:'quality-common'},
 fine:{name:'精良',rank:1,power:1.16,value:1.18,cls:'quality-fine'},
 rare:{name:'稀有',rank:2,power:1.38,value:1.48,cls:'quality-rare'},
 epic:{name:'史诗',rank:3,power:1.70,value:1.95,cls:'quality-epic'},
 legend:{name:'传说',rank:4,power:2.15,value:2.70,cls:'quality-legend'}
};
var QORDER=['common','fine','rare','epic','legend'];

var MATERIALS={
 wood:'木材',ore:'铁矿',hide:'兽皮',crystal:'魔晶',ember:'火核',rune:'符文碎片'
};

var RECIPES={
 bronzeSword:{name:'铜制长剑',slot:'weapon',type:'武器',basePower:14,baseValue:180,cost:45,need:{ore:3,wood:1},tags:['weapon','strength'],unlock:'start'},
 leatherArmor:{name:'皮革胸甲',slot:'armor',type:'防具',basePower:12,baseValue:165,cost:40,need:{hide:4,wood:1},tags:['armor','defense'],unlock:'start'},
 hunterBow:{name:'猎人短弓',slot:'weapon',type:'武器',basePower:18,baseValue:260,cost:65,need:{wood:4,hide:2},tags:['weapon','agility'],unlock:'forest'},
 ironArmor:{name:'精铁重甲',slot:'armor',type:'防具',basePower:26,baseValue:420,cost:110,need:{ore:7,hide:2},tags:['armor','defense','heavy'],unlock:'mine'},
 crystalRing:{name:'魔晶戒指',slot:'accessory',type:'饰品',basePower:20,baseValue:520,cost:135,need:{crystal:3,ore:2},tags:['accessory','magic'],unlock:'order'},
 shadowBoots:{name:'影行靴',slot:'armor',type:'防具',basePower:24,baseValue:470,cost:120,need:{hide:5,crystal:2},tags:['armor','agility'],unlock:'forest2'},
 flameSword:{name:'炎纹长剑',slot:'weapon',type:'武器',basePower:38,baseValue:880,cost:240,need:{ore:8,crystal:3,ember:2},tags:['weapon','strength','fire'],unlock:'cave'}
};

var AFFIXES=[
 {id:'sharp',name:'锋利',tags:['strength'],power:[3,8],value:.12},
 {id:'sturdy',name:'坚固',tags:['defense'],power:[3,7],value:.10},
 {id:'swift',name:'迅捷',tags:['agility'],power:[2,6],value:.13},
 {id:'lucky',name:'幸运',tags:['luck'],power:[1,4],value:.18},
 {id:'arcane',name:'秘能',tags:['magic'],power:[3,8],value:.16},
 {id:'flame',name:'灼热',tags:['fire'],power:[4,9],value:.20},
 {id:'prestige',name:'华贵',tags:['luxury'],power:[0,2],value:.28}
];

var EMPLOYEES=[
 {id:'brann',name:'布兰',job:'战士',base:24,trait:'冒险时战力 +18%；营业时武器成交率 +6%。'},
 {id:'mira',name:'米拉',job:'斥候',base:20,trait:'冒险掉落 +20%；稀有材料概率 +10%。'},
 {id:'edda',name:'艾达',job:'商人',base:11,trait:'营业时顾客数量 +2，售价容忍度 +10%。'},
 {id:'otto',name:'奥托',job:'工匠',base:14,trait:'锻造时品质评分 +16，材料节省概率 12%。'}
];

var REGIONS={
 forest:{name:'翠绿森林',need:34,drops:{wood:[3,6],hide:[2,5],crystal:[0,1]},desc:'基础资源丰富。首次成功发现「猎人短弓」。'},
 mine:{name:'黑石矿坑',need:58,drops:{ore:[4,8],crystal:[1,3]},desc:'铁矿主产区。首次成功发现「精铁重甲」。'},
 cave:{name:'余烬洞窟',need:92,drops:{ore:[3,6],crystal:[1,3],ember:[1,3]},desc:'高风险区域。首次成功发现「炎纹长剑」。'},
 tower:{name:'废弃高塔',need:128,drops:{crystal:[2,5],rune:[1,3]},desc:'终局测试区，掉落符文碎片。'}
};

var EVENTS=[
 {id:'calm',name:'平静的一天',desc:'市场供需平稳。',cust:0,budget:1,demand:{}},
 {id:'war',name:'北境战事',desc:'武器需求激增，佣兵明显增多。',cust:1,budget:1.08,demand:{weapon:1.35},types:{mercenary:1.6}},
 {id:'ball',name:'贵族舞会',desc:'饰品与高品质装备溢价明显。',cust:1,budget:1.18,demand:{accessory:1.45,luxury:1.25},types:{noble:1.8,collector:1.4}},
 {id:'hunt',name:'秋季狩猎',desc:'猎人集中采购敏捷向装备。',cust:1,budget:1.05,demand:{agility:1.40},types:{hunter:1.8}},
 {id:'festival',name:'丰收祭',desc:'客流增加，整体预算提高。',cust:3,budget:1.12,demand:{}},
 {id:'mineAccident',name:'矿坑事故',desc:'金属装备价格上扬，但矿坑收益下降。',cust:0,budget:1.06,demand:{defense:1.18,strength:1.18},minePenalty:.75}
];

var CUSTOMERS={
 novice:{name:'新手冒险者',budget:[220,650],likes:['weapon','armor'],qualityMax:1,priceSense:1.25},
 mercenary:{name:'佣兵',budget:[650,1900],likes:['weapon','strength','defense'],qualityMax:3,priceSense:.90},
 hunter:{name:'猎人',budget:[600,1800],likes:['agility','weapon'],qualityMax:3,priceSense:.95},
 noble:{name:'贵族',budget:[1600,5200],likes:['accessory','luxury','magic'],qualityMax:4,priceSense:.48},
 collector:{name:'收藏家',budget:[2600,9000],likes:['fire','magic','luck','luxury'],qualityMax:4,priceSense:.30}
};

function rnd(a,b){return Math.floor(Math.random()*(b-a+1))+a}
function pick(a){return a[Math.floor(Math.random()*a.length)]}
function clamp(x,a,b){return Math.max(a,Math.min(b,x))}
function uid(){return 'i'+Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function fmt(n){return Math.round(n).toLocaleString('zh-CN')}

function baseState(){
 var staff=EMPLOYEES.map(function(e,i){
  return {id:e.id,role:i===0?'adventure':i===1?'adventure':i===2?'shop':'forge',equip:{weapon:null,armor:null,accessory:null}}
 });
 return {
  v:2,gold:1600,gems:12,day:1,rep:0,shopLv:1,forgeLv:1,tab:'shop',
  mats:{wood:12,ore:10,hide:10,crystal:4,ember:2,rune:0},
  staff:staff,inventory:[],shelf:[],orders:[],unlocked:{bronzeSword:true,leatherArmor:true},
  region:'forest',event:EVENTS[0],lastReport:null,discover:{forest:0,mine:0,cave:0,tower:0}
 };
}

function migrate(){
 var s=null;
 try{s=JSON.parse(localStorage.getItem(SAVE_KEY)||'null')}catch(e){}
 if(s&&s.v===2)return s;
 var old=null;
 for(var i=0;i<OLD_KEYS.length&&!old;i++){try{old=JSON.parse(localStorage.getItem(OLD_KEYS[i])||'null')}catch(e){}}
 s=baseState();
 if(old){
  if(old.gold!=null)s.gold=Math.max(800,Number(old.gold)||1600);
  if(old.gems!=null)s.gems=Number(old.gems)||12;
  if(old.day!=null)s.day=Number(old.day)||1;
  if(old.mats){
   for(var k in s.mats)if(old.mats[k]!=null)s.mats[k]=Number(old.mats[k])||0;
  }
  if(old.forgeLv!=null)s.forgeLv=Math.max(1,Number(old.forgeLv)||1);
 }
 return s;
}
var S=migrate();

function save(){try{localStorage.setItem(SAVE_KEY,JSON.stringify(S))}catch(e){}}
function eventById(id){for(var i=0;i<EVENTS.length;i++)if(EVENTS[i].id===id)return EVENTS[i];return EVENTS[0]}
if(!S.event||!S.event.id)S.event=EVENTS[0];

function empDef(id){for(var i=0;i<EMPLOYEES.length;i++)if(EMPLOYEES[i].id===id)return EMPLOYEES[i]}
function qDef(q){return QUALITY[q]}
function recipe(id){return RECIPES[id]}
function itemPower(it){
 var r=recipe(it.recipeId),q=qDef(it.quality),p=Math.round(r.basePower*q.power);
 for(var i=0;i<it.affixes.length;i++)p+=it.affixes[i].power||0;
 return p;
}
function itemValue(it){
 var r=recipe(it.recipeId),q=qDef(it.quality),v=r.baseValue*q.value;
 for(var i=0;i<it.affixes.length;i++)v*=1+(it.affixes[i].value||0);
 return Math.round(v);
}
function itemTags(it){
 var r=recipe(it.recipeId),tags=r.tags.slice();
 for(var i=0;i<it.affixes.length;i++)tags=tags.concat(it.affixes[i].tags||[]);
 return tags;
}
function staffState(id){for(var i=0;i<S.staff.length;i++)if(S.staff[i].id===id)return S.staff[i]}
function findItem(uidv){
 for(var i=0;i<S.inventory.length;i++)if(S.inventory[i].uid===uidv)return {where:'inventory',index:i,item:S.inventory[i]};
 for(var j=0;j<S.shelf.length;j++)if(S.shelf[j].item.uid===uidv)return {where:'shelf',index:j,item:S.shelf[j].item};
 return null;
}
function isEquipped(uidv){
 for(var i=0;i<S.staff.length;i++){
  var e=S.staff[i].equip;
  if(e.weapon===uidv||e.armor===uidv||e.accessory===uidv)return true;
 }
 return false;
}
function employeePower(st){
 var d=empDef(st.id),p=d.base;
 ['weapon','armor','accessory'].forEach(function(slot){
  var id=st.equip[slot],f=id?findItem(id):null;
  if(f)p+=itemPower(f.item);
 });
 if(st.id==='brann'&&st.role==='adventure')p=Math.round(p*1.18);
 return p;
}
function advTeamPower(){
 var p=0;for(var i=0;i<S.staff.length;i++)if(S.staff[i].role==='adventure')p+=employeePower(S.staff[i]);
 return p;
}
function forgeScore(){
 var score=(S.forgeLv-1)*9;
 for(var i=0;i<S.staff.length;i++)if(S.staff[i].role==='forge'){
  score+=S.staff[i].id==='otto'?16:5;
 }
 return score;
}
function shopBonuses(){
 var b={visitors:0,tolerance:0,weapon:0};
 for(var i=0;i<S.staff.length;i++)if(S.staff[i].role==='shop'){
  if(S.staff[i].id==='edda'){b.visitors+=2;b.tolerance+=.10}
  else if(S.staff[i].id==='brann')b.weapon+=.06;
  else b.visitors+=1;
 }
 return b;
}
function scoutBonus(){
 var b={loot:1,rare:0};
 for(var i=0;i<S.staff.length;i++)if(S.staff[i].role==='adventure'&&S.staff[i].id==='mira'){b.loot+=.20;b.rare+=.10}
 return b;
}
function shelfCap(){return [0,3,4,5,6,8][S.shopLv]||8}
function stageName(){
 if(S.rep<80)return '街角铁匠铺';
 if(S.rep<220)return '小有名气';
 if(S.rep<500)return '城镇名店';
 if(S.rep<1000)return '王都工坊';
 return '传奇工坊';
}
function currentEvent(){return eventById(S.event.id)}
function materialText(need){
 var a=[];for(var k in need)a.push(MATERIALS[k]+' '+(S.mats[k]||0)+'/'+need[k]);return a.join(' · ')
}
function canCraft(id){
 var r=recipe(id);if(!S.unlocked[id])return false;
 if(S.gold<r.cost)return false;
 for(var k in r.need)if((S.mats[k]||0)<r.need[k])return false;
 return true;
}
function qualityRoll(){
 var sc=forgeScore(),x=Math.random()*100;
 var legend=clamp((sc-40)*.18,0,7);
 var epic=clamp(2+sc*.22,2,20);
 var rare=clamp(8+sc*.34,8,32);
 var fine=clamp(30+sc*.25,30,48);
 if(x<legend)return 'legend';
 if(x<legend+epic)return 'epic';
 if(x<legend+epic+rare)return 'rare';
 if(x<legend+epic+rare+fine)return 'fine';
 return 'common';
}
function rollAffixes(q){
 var rank=qDef(q).rank,count=0;
 if(rank===0)count=Math.random()<.22?1:0;
 if(rank===1)count=1;
 if(rank===2)count=1+(Math.random()<.45?1:0);
 if(rank===3)count=2;
 if(rank===4)count=2+(Math.random()<.55?1:0);
 var pool=AFFIXES.slice(),out=[];
 for(var i=0;i<count&&pool.length;i++){
  var idx=rnd(0,pool.length-1),a=pool.splice(idx,1)[0];
  var scale=1+rank*.18;
  out.push({id:a.id,name:a.name,tags:a.tags,power:Math.round(rnd(a.power[0],a.power[1])*scale),value:a.value*(1+rank*.08)});
 }
 return out;
}
function craft(id){
 if(!canCraft(id))return toast('金币或材料不足');
 var r=recipe(id),saved=false;
 for(var k in r.need){
  var need=r.need[k];
  if(staffState('otto').role==='forge'&&Math.random()<.12){need=Math.max(0,need-1);saved=true}
  S.mats[k]-=need;
 }
 S.gold-=r.cost;
 var q=qualityRoll(),it={uid:uid(),recipeId:id,quality:q,affixes:rollAffixes(q),costBasis:r.cost};
 S.inventory.push(it);save();render();
 toast((saved?'奥托节省了材料 · ':'')+'锻造完成：'+qDef(q).name+'·'+r.name);
}
window.craft=craft;

function priceMultLabel(m){return m===.8?'促销 80%':m===1?'市价 100%':m===1.2?'加价 120%':'精品价 150%'}
function listItem(uidv){
 if(S.shelf.length>=shelfCap())return toast('货架已满');
 var f=findItem(uidv);if(!f||f.where!=='inventory')return;
 for(var si=0;si<S.staff.length;si++)for(var sl in S.staff[si].equip)if(S.staff[si].equip[sl]===uidv)return toast('已装备的物品不能上架');
 var it=S.inventory.splice(f.index,1)[0];
 S.shelf.push({item:it,mult:1});
 save();render();toast('已上架 '+recipe(it.recipeId).name);
}
window.listItem=listItem;
function unlist(i){S.inventory.push(S.shelf.splice(i,1)[0].item);save();render()}
window.unlist=unlist;
function setPrice(i,m){S.shelf[i].mult=m;save();render()}
window.setPrice=setPrice;

function equipItem(staffId,uidv){
 var st=staffState(staffId),f=findItem(uidv);if(!st||!f||f.where!=='inventory')return;
 var it=f.item,slot=recipe(it.recipeId).slot;
 var old=st.equip[slot];
 st.equip[slot]=uidv;
 if(old){}
 save();closeModal();render();toast(empDef(staffId).name+'装备了 '+recipe(it.recipeId).name);
}
window.equipItem=equipItem;
function unequip(staffId,slot){var st=staffState(staffId);st.equip[slot]=null;save();render()}
window.unequip=unequip;

function setRole(id,role){staffState(id).role=role;save();render()}
window.setRole=setRole;
function selectRegion(id){S.region=id;save();render()}
window.selectRegion=selectRegion;

function chooseCustomerType(ev){
 var keys=Object.keys(CUSTOMERS),weights={novice:4,mercenary:3,hunter:2.4,noble:1.1,collector:.45};
 if(ev.types)for(var k in ev.types)weights[k]=(weights[k]||1)*ev.types[k];
 var total=0;keys.forEach(function(k){total+=weights[k]});
 var x=Math.random()*total,c=0;for(var i=0;i<keys.length;i++){c+=weights[keys[i]];if(x<=c)return keys[i]}return 'novice';
}
function demandMult(it,ev){
 var tags=itemTags(it),m=1;
 for(var i=0;i<tags.length;i++)if(ev.demand&&ev.demand[tags[i]])m*=ev.demand[tags[i]];
 return m;
}
function customerTry(type,listing,ev,bonus){
 var c=CUSTOMERS[type],it=listing.item,market=itemValue(it)*demandMult(it,ev);
 var price=Math.round(market*listing.mult),budget=rnd(c.budget[0],c.budget[1])*ev.budget;
 var tags=itemTags(it),pref=0;
 for(var i=0;i<c.likes.length;i++)if(tags.indexOf(c.likes[i])>=0)pref+=.18;
 var qr=qDef(it.quality).rank;
 if(qr>c.qualityMax)pref+=(type==='collector'||type==='noble')?.18:-.08;
 var ratio=price/Math.max(1,market),pricePenalty=Math.max(0,ratio-1)*(c.priceSense-bonus.tolerance)*.95;
 var prob=.24+pref+qr*.04+S.rep/4000-pricePenalty;
 if(tags.indexOf('weapon')>=0)prob+=bonus.weapon;
 if(price>budget)prob-=.55+(price-budget)/Math.max(200,budget)*.45;
 return {prob:clamp(prob,.02,.97),price:price,budget:budget,market:market};
}
function simulateShop(){
 var ev=currentEvent(),bonus=shopBonuses();
 var visitors=Math.max(2,5+S.shopLv*2+bonus.visitors+(ev.cust||0)+rnd(-1,2));
 var sales=[],feedback=[],revenue=0,cost=0,repGain=0;
 for(var v=0;v<visitors;v++){
  if(!S.shelf.length){feedback.push('有顾客进店，但货架是空的。');continue}
  var type=chooseCustomerType(ev),best=null;
  for(var i=0;i<S.shelf.length;i++){
   var t=customerTry(type,S.shelf[i],ev,bonus);
   var score=t.prob+Math.random()*.24;
   if(!best||score>best.score)best={index:i,t:t,score:score,type:type};
  }
  if(best&&Math.random()<best.t.prob){
   var li=S.shelf.splice(best.index,1)[0],it=li.item;
   revenue+=best.t.price;cost+=it.costBasis||0;
   var rg=1+qDef(it.quality).rank;
   repGain+=rg;
   sales.push(CUSTOMERS[best.type].name+'购买 '+qDef(it.quality).name+'·'+recipe(it.recipeId).name+'，'+fmt(best.t.price)+'G');
  }else if(feedback.length<5){
   var msg=best&&best.t.price>best.t.budget?'预算不够，顾客放弃了。':'顾客看了看，没有找到足够心动的商品。';
   feedback.push((best?CUSTOMERS[best.type].name:'顾客')+'：'+msg);
  }
 }
 S.gold+=revenue;S.rep+=repGain;
 return {visitors:visitors,sales:sales,revenue:revenue,cost:cost,profit:revenue-cost,rep:repGain,feedback:feedback};
}
function resolveAdventure(){
 var region=REGIONS[S.region],team=S.staff.filter(function(x){return x.role==='adventure'});
 if(!team.length)return {text:'今天没有安排冒险员工。',ok:false};
 var power=advTeamPower(),chance=clamp(.45+(power-region.need)/110,.16,.94),ok=Math.random()<chance,loot=[];
 if(ok){
  var b=scoutBonus(),ev=currentEvent();
  for(var k in region.drops){
   var range=region.drops[k],n=rnd(range[0],range[1]);
   if(k==='crystal'||k==='ember'||k==='rune')if(Math.random()<b.rare)n+=1;
   n=Math.round(n*b.loot);
   if(S.region==='mine'&&ev.minePenalty)n=Math.max(0,Math.round(n*ev.minePenalty));
   if(n>0){S.mats[k]=(S.mats[k]||0)+n;loot.push(MATERIALS[k]+'+'+n)}
  }
  S.discover[S.region]=(S.discover[S.region]||0)+1;
  if(S.region==='forest'&&!S.unlocked.hunterBow)S.unlocked.hunterBow=true;
  else if(S.region==='forest'&&S.discover.forest>=3&&!S.unlocked.shadowBoots)S.unlocked.shadowBoots=true;
  if(S.region==='mine'&&!S.unlocked.ironArmor)S.unlocked.ironArmor=true;
  if(S.region==='cave'&&!S.unlocked.flameSword)S.unlocked.flameSword=true;
  return {ok:true,text:region.name+'成功，战力 '+power+'，成功率 '+Math.round(chance*100)+'%，获得 '+loot.join('、')};
 }
 return {ok:false,text:region.name+'失败，战力 '+power+'，成功率 '+Math.round(chance*100)+'%。'};
}
function generateOrder(){
 var pool=[
  {name:'城卫队采购',slot:'weapon',minQ:0,qty:rnd(2,3),mult:1.28,rep:10,days:3},
  {name:'佣兵团补给',slot:'armor',minQ:0,qty:rnd(2,3),mult:1.22,rep:9,days:3},
  {name:'猎人公会委托',tag:'agility',minQ:1,qty:1,mult:1.42,rep:13,days:4},
  {name:'贵族私人订单',slot:'accessory',minQ:2,qty:1,mult:1.75,rep:20,days:5},
  {name:'收藏家征集',minQ:3,qty:1,mult:2.05,rep:24,days:5}
 ];
 var p=pick(pool),base=320*p.qty*(1+p.minQ*.45);
 return {id:uid(),name:p.name,slot:p.slot||null,tag:p.tag||null,minQ:p.minQ,qty:p.qty,reward:Math.round(base*p.mult),rep:p.rep,days:p.days};
}
function ensureOrders(){while(S.orders.length<3)S.orders.push(generateOrder())}
function orderMatches(it,o){
 var r=recipe(it.recipeId);if(qDef(it.quality).rank<o.minQ)return false;
 if(o.slot&&r.slot!==o.slot)return false;
 if(o.tag&&itemTags(it).indexOf(o.tag)<0)return false;
 return true;
}
function fulfillOrder(id){
 var oi=-1;for(var i=0;i<S.orders.length;i++)if(S.orders[i].id===id)oi=i;
 if(oi<0)return;var o=S.orders[oi],idx=[];
 for(var j=0;j<S.inventory.length;j++)if(!isEquipped(S.inventory[j].uid)&&orderMatches(S.inventory[j],o))idx.push(j);
 if(idx.length<o.qty)return toast('符合要求的库存不足');
 idx=idx.slice(0,o.qty).sort(function(a,b){return b-a});idx.forEach(function(n){S.inventory.splice(n,1)});
 S.gold+=o.reward;S.rep+=o.rep;
 if(o.name==='贵族私人订单'&&!S.unlocked.crystalRing)S.unlocked.crystalRing=true;
 S.orders.splice(oi,1);ensureOrders();save();render();toast('订单完成：+'+fmt(o.reward)+'G / 声望+'+o.rep);
}
window.fulfillOrder=fulfillOrder;

function advanceOrders(){
 var expired=0;
 for(var i=S.orders.length-1;i>=0;i--){S.orders[i].days--;if(S.orders[i].days<=0){S.orders.splice(i,1);S.rep=Math.max(0,S.rep-4);expired++}}
 ensureOrders();return expired;
}
function nextEvent(){S.event=pick(EVENTS)}
function openShop(){
 var shop=simulateShop(),adv=resolveAdventure(),expired=advanceOrders();
 var oldEvent=currentEvent().name;
 S.day++;nextEvent();ensureOrders();
 S.lastReport={day:S.day-1,event:oldEvent,shop:shop,adv:adv,expired:expired};
 save();render();showReport();
}
window.openShop=openShop;

function qualityName(rank){return qDef(QORDER[rank]||'common').name}
function orderDesc(o){
 var a=[];if(o.slot)a.push(o.slot==='weapon'?'武器':o.slot==='armor'?'防具':'饰品');if(o.tag)a.push('需要 '+o.tag);a.push('品质 '+qualityName(o.minQ)+'+');a.push('数量 '+o.qty);
 return a.join(' · ');
}
function canUpgradeShop(){
 var costs=[0,0,700,2200,6000,14000],reps=[0,0,30,140,380,850];
 var next=S.shopLv+1;if(next>5)return null;return {cost:costs[next],rep:reps[next]};
}
function upgradeShop(){
 var n=canUpgradeShop();if(!n)return;
 if(S.gold<n.cost||S.rep<n.rep)return toast('金币或声望不足');
 S.gold-=n.cost;S.shopLv++;save();render();toast('店铺升级到 Lv.'+S.shopLv);
}
window.upgradeShop=upgradeShop;
function upgradeForge(){
 var cost=500*S.forgeLv*S.forgeLv;if(S.gold<cost)return toast('金币不足');
 S.gold-=cost;S.forgeLv++;save();render();toast('锻造台升级到 Lv.'+S.forgeLv);
}
window.upgradeForge=upgradeForge;

function top(){
 return '<div class=top><div class=brand><b>百川铁匠铺</b><small>Gameplay Demo v0.6.0 · '+stageName()+'</small></div>'+
 '<div class=resources><div class=pill><small>金币</small><b>'+fmt(S.gold)+'G</b></div><div class=pill><small>声望</small><b>'+fmt(S.rep)+'</b></div><div class=pill><small>日期</small><b>D'+S.day+'</b></div></div></div>';
}
function nav(){
 var a=[['shop','▣','经营'],['forge','◆','锻造'],['staff','●','员工'],['adventure','▲','冒险'],['inventory','≡','仓库']],x='<div class=nav>';
 for(var i=0;i<a.length;i++)x+='<button class="'+(S.tab===a[i][0]?'on':'')+'" onclick="go(\''+a[i][0]+'\')"><b>'+a[i][1]+'</b>'+a[i][2]+'</button>';
 return x+'</div>';
}
window.go=function(t){S.tab=t;save();render()}
function render(){ensureOrders();app.innerHTML=top()+'<div class=main>'+view()+'</div>'+nav()}
function view(){
 if(S.tab==='shop')return shopView();
 if(S.tab==='forge')return forgeView();
 if(S.tab==='staff')return staffView();
 if(S.tab==='adventure')return adventureView();
 return inventoryView();
}

function shopView(){
 var ev=currentEvent(),up=canUpgradeShop(),shopB=shopBonuses();
 var x='<div class=scroll><div class=event><strong>'+ev.name+'</strong><p>'+ev.desc+'</p></div>';
 x+='<div class=card><div class=cardHead><b>店铺经营</b><span>货架 '+S.shelf.length+'/'+shelfCap()+'</span></div><div class=cardBody>'+
 '<div class=kpis><div class=kpi><small>店铺Lv</small><b>'+S.shopLv+'</b></div><div class=kpi><small>客流加成</small><b>+'+shopB.visitors+'</b></div><div class=kpi><small>售价容忍</small><b>+'+Math.round(shopB.tolerance*100)+'%</b></div><div class=kpi><small>冒险战力</small><b>'+advTeamPower()+'</b></div></div></div></div>';
 x+='<div class=card><div class=cardHead><b>货架</b><span>定价会直接影响成交率</span></div><div class=cardBody>';
 if(!S.shelf.length)x+='<div class=mini>货架为空。去「仓库」把装备上架。</div>';
 for(var i=0;i<S.shelf.length;i++){
  var l=S.shelf[i],it=l.item,r=recipe(it.recipeId),mv=itemValue(it),price=Math.round(mv*l.mult);
  x+='<div class=item><div class=itemTop><div class=itemName><b class="'+qDef(it.quality).cls+'">'+qDef(it.quality).name+'·'+r.name+'</b><small>战力 '+itemPower(it)+' · 市值 '+fmt(mv)+'G · 售价 '+fmt(price)+'G</small></div><button class=btn onclick="unlist('+i+')">下架</button></div>'+
  '<div class=priceBar>'+[.8,1,1.2,1.5].map(function(m){return '<button class="'+(l.mult===m?'on':'')+'" onclick="setPrice('+i+','+m+')">'+(m*100)+'%</button>'}).join('')+'</div></div>';
 }
 x+='</div></div>';
 x+='<div class=card><div class=cardHead><b>订单</b><span>订单只消耗仓库库存</span></div><div class=cardBody>';
 for(var j=0;j<S.orders.length;j++){
  var o=S.orders[j],count=S.inventory.filter(function(it){return !isEquipped(it.uid)&&orderMatches(it,o)}).length;
  x+='<div class=order><h3>'+o.name+'</h3><p>'+orderDesc(o)+'<br>奖励 '+fmt(o.reward)+'G / 声望+'+o.rep+' · 剩余 '+o.days+'天</p><div class=row><span class="badge '+(count>=o.qty?'good':'')+'">库存 '+count+'/'+o.qty+'</span><span class=space></span><button class="btn green" '+(count>=o.qty?'':'disabled')+' onclick="fulfillOrder(\''+o.id+'\')">交付</button></div></div>';
 }
 x+='</div></div>';
 if(up)x+='<div class=card><div class=cardHead><b>扩建店铺</b><span>下一等级增加货架与客流</span></div><div class=cardBody><div class=row><div class=mini>需要 '+fmt(up.cost)+'G / 声望 '+up.rep+'</div><span class=space></span><button class=btn onclick="upgradeShop()">升级到 Lv.'+(S.shopLv+1)+'</button></div></div></div>';
 x+='<button class="big green" onclick="openShop()">开始营业并结束 Day '+S.day+'</button>';
 if(S.lastReport)x+='<button class=big style="margin-top:6px;background:#2a2118;border-color:#54412e" onclick="showReport()">查看上次营业报告</button>';
 return x+'</div>';
}

function forgeView(){
 var score=forgeScore(),cost=500*S.forgeLv*S.forgeLv;
 var x='<div class=scroll><div class=card><div class=cardHead><b>锻造台 Lv.'+S.forgeLv+'</b><span>品质评分 '+score+'</span></div><div class=cardBody>'+
 '<div class=mini>安排员工到「锻造」岗位会提升品质。奥托在锻造岗时还有 12% 概率节省一份材料。</div><div class=sep></div>'+
 '<div class=row><span class=mini>升级费用 '+fmt(cost)+'G</span><span class=space></span><button class=btn onclick="upgradeForge()">升级锻造台</button></div></div></div>';
 x+='<div class=card><div class=cardHead><b>配方</b><span>冒险和特殊订单会发现新配方</span></div><div class=cardBody><div class=grid2>';
 for(var id in RECIPES){
  var r=RECIPES[id],locked=!S.unlocked[id];
  x+='<div class=recipe><h3>'+(locked?'？？？':r.name)+'</h3><p>'+(locked?'尚未发现配方。':r.type+' · 基础战力 '+r.basePower+'<br>'+materialText(r.need)+'<br>制作费 '+r.cost+'G')+'</p>'+
  '<button class=btn '+(canCraft(id)?'gold':'')+' '+(canCraft(id)?'':'disabled')+' onclick="craft(\''+id+'\')">'+(locked?'未解锁':'锻造')+'</button></div>';
 }
 x+='</div></div></div></div>';return x;
}

function staffView(){
 var x='<div class=scroll><div class=event><strong>岗位分配</strong><p>同一个员工每天只能承担一种主要岗位。锻造品质、营业成交和冒险收益都由这里决定。</p></div>';
 for(var i=0;i<S.staff.length;i++){
  var st=S.staff[i],d=empDef(st.id),power=employeePower(st);
  x+='<div class=staff><div class=row><h3>'+d.name+' · '+d.job+'</h3><span class=space></span><span class=badge>战力 '+power+'</span></div><div class=trait>'+d.trait+'</div>'+
  '<div class=roles>'+['adventure','shop','forge','rest'].map(function(role){
   var names={adventure:'冒险',shop:'营业',forge:'锻造',rest:'休息'};
   return '<button class="'+(st.role===role?'on':'')+'" onclick="setRole(\''+st.id+'\',\''+role+'\')">'+names[role]+'</button>';
  }).join('')+'</div>'+
  '<div class=slotLine>'+['weapon','armor','accessory'].map(function(slot){
   var uidv=st.equip[slot],f=uidv?findItem(uidv):null,name=f?recipe(f.item.recipeId).name:'空';
   return '<div class=slotTag onclick="chooseEquip(\''+st.id+'\',\''+slot+'\')">'+({weapon:'武器',armor:'防具',accessory:'饰品'}[slot])+'：'+name+'</div>';
  }).join('')+'</div></div>';
 }
 return x+'</div>';
}
window.chooseEquip=function(staffId,slot){
 var list=S.inventory.filter(function(it){return recipe(it.recipeId).slot===slot&&!isEquipped(it.uid)});
 var st=staffState(staffId),html='<div class=mini>只显示仓库中的 '+({weapon:'武器',armor:'防具',accessory:'饰品'}[slot])+'。装备仅影响数值，不再切换人物贴图。</div><div class=sep></div>';
 if(st.equip[slot])html+='<button class="btn red" onclick="unequip(\''+staffId+'\',\''+slot+'\');closeModal()">卸下当前装备</button><div class=sep></div>';
 if(!list.length)html+='<div class=mini>仓库没有可装备物品。</div>';
 for(var i=0;i<list.length;i++){var it=list[i],r=recipe(it.recipeId);html+='<div class=item><div class=row><div class=itemName><b class="'+qDef(it.quality).cls+'">'+qDef(it.quality).name+'·'+r.name+'</b><small>战力 '+itemPower(it)+' · '+affixText(it)+'</small></div><button class=btn onclick="equipItem(\''+staffId+'\',\''+it.uid+'\')">装备</button></div></div>'}
 modal(empDef(staffId).name+' · 选择装备',html);
}

function adventureView(){
 var power=advTeamPower(),x='<div class=scroll><div class=card><div class=cardHead><b>今日冒险计划</b><span>将在“开始营业”时同步结算</span></div><div class=cardBody><div class=kpis><div class=kpi><small>队伍战力</small><b>'+power+'</b></div><div class=kpi><small>冒险人数</small><b>'+S.staff.filter(function(a){return a.role==='adventure'}).length+'</b></div><div class=kpi><small>掉落加成</small><b>+'+Math.round((scoutBonus().loot-1)*100)+'%</b></div><div class=kpi><small>当前区域</small><b>'+REGIONS[S.region].name.slice(0,4)+'</b></div></div></div></div>';
 for(var id in REGIONS){
  var r=REGIONS[id],chance=clamp(.45+(power-r.need)/110,.16,.94);
  x+='<div class="region '+(S.region===id?'selected':'')+'" onclick="selectRegion(\''+id+'\')"><div class=row><h3>'+r.name+'</h3><span class=space></span><span class="badge '+(chance>=.7?'good':chance<.45?'bad':'')+'">预计 '+Math.round(chance*100)+'%</span></div><p>推荐战力 '+r.need+' · '+r.desc+'</p></div>';
 }
 x+='<div class=warn>冒险不会单独推进日期。选择区域后，回「经营」点击开始营业，冒险与商店会在同一天一起结算。</div></div>';return x;
}

function affixText(it){
 if(!it.affixes.length)return '无词条';
 return it.affixes.map(function(a){return a.name+' +'+a.power}).join(' / ');
}
function inventoryView(){
 var x='<div class=scroll><div class=card><div class=cardHead><b>材料</b><span>所有贴图展示已移除</span></div><div class=cardBody><div class=grid3>';
 for(var k in MATERIALS)x+='<div class=kpi><small>'+MATERIALS[k]+'</small><b>'+fmt(S.mats[k]||0)+'</b></div>';
 x+='</div></div></div><div class=card><div class=cardHead><b>装备库存</b><span>'+S.inventory.length+' 件</span></div><div class=cardBody>';
 if(!S.inventory.length)x+='<div class=mini>仓库暂无装备。去锻造台制作。</div>';
 for(var i=0;i<S.inventory.length;i++){
  var it=S.inventory[i],r=recipe(it.recipeId),equipped=false,who='';
  for(var s=0;s<S.staff.length;s++)for(var sl in S.staff[s].equip)if(S.staff[s].equip[sl]===it.uid){equipped=true;who=empDef(S.staff[s].id).name}
  x+='<div class=item><div class=itemTop><div class=itemName><b class="'+qDef(it.quality).cls+'">'+qDef(it.quality).name+'·'+r.name+'</b><small>战力 '+itemPower(it)+' · 市值 '+fmt(itemValue(it))+'G · '+affixText(it)+(equipped?' · 已装备：'+who:'')+'</small></div>'+
  (equipped?'<span class="badge gold">使用中</span>':'<button class="btn green" onclick="listItem(\''+it.uid+'\')">上架</button>')+'</div></div>';
 }
 x+='</div></div><div class=card><div class=cardHead><b>Demo工具</b><span>方便快速测试系统</span></div><div class=cardBody><div class=row><button class=btn onclick="demoSupply()">测试补给</button><button class="btn red" onclick="resetDemo()">重置Demo</button></div><div class=mini style="margin-top:7px">测试补给：+1000G，并补充一批基础材料。不会清存档。</div></div></div></div>';
 return x;
}
window.demoSupply=function(){S.gold+=1000;S.mats.wood+=8;S.mats.ore+=8;S.mats.hide+=8;S.mats.crystal+=3;S.mats.ember+=1;save();render();toast('测试补给已发放')}
window.resetDemo=function(){if(confirm('确定重置 v0.6.0 Demo 存档？')){S=baseState();ensureOrders();save();render()}}

function showReport(){
 if(!S.lastReport)return toast('还没有营业报告');
 var r=S.lastReport,html='<div class=reportLine><span>日期</span><b>Day '+r.day+'</b></div><div class=reportLine><span>市场事件</span><b>'+r.event+'</b></div>'+
 '<div class=reportLine><span>来客</span><b>'+r.shop.visitors+' 人</b></div><div class=reportLine><span>成交</span><b>'+r.shop.sales.length+' 笔</b></div>'+
 '<div class=reportLine><span>营业额</span><b>'+fmt(r.shop.revenue)+'G</b></div><div class=reportLine><span>账面利润</span><b>'+fmt(r.shop.profit)+'G</b></div>'+
 '<div class=reportLine><span>声望</span><b>+'+r.shop.rep+'</b></div><div class=sep></div><div class=mini><b style="color:#ead2a0">冒险结果</b><br>'+r.adv.text+'</div>';
 if(r.shop.sales.length){html+='<div class=sep></div><div class=mini><b style="color:#ead2a0">成交记录</b></div>';for(var i=0;i<Math.min(6,r.shop.sales.length);i++)html+='<div class=feedback>'+r.shop.sales[i]+'</div>'}
 if(r.shop.feedback.length){html+='<div class=sep></div><div class=mini><b style="color:#ead2a0">顾客反馈</b></div>';for(var j=0;j<Math.min(4,r.shop.feedback.length);j++)html+='<div class=feedback>'+r.shop.feedback[j]+'</div>'}
 if(r.expired)html+='<div class=feedback style="border-color:#84433d">有 '+r.expired+' 个订单逾期，声望受到影响。</div>';
 modal('Day '+r.day+' 营业报告',html);
}
window.showReport=showReport;

function modal(title,body){
 closeModal();var d=document.createElement('div');d.className='modal';d.innerHTML='<div class=modalBox><div class=modalHead><b>'+title+'</b><button class=close onclick="closeModal()">×</button></div><div class=modalBody>'+body+'</div></div>';document.querySelector('.main').appendChild(d);
}
window.closeModal=function(){var m=document.querySelector('.modal');if(m)m.remove()}
function toast(t){var d=document.createElement('div');d.style.cssText='position:absolute;left:50%;bottom:76px;transform:translateX(-50%);z-index:60;background:#090705;border:1px solid #6b5036;color:#ffe2a6;padding:8px 12px;border-radius:5px;font-size:8px;white-space:nowrap';d.textContent=t;document.querySelector('.main').appendChild(d);setTimeout(function(){if(d.parentNode)d.remove()},1400)}

ensureOrders();save();render();
})();
